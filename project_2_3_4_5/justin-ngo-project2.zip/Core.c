#include "Core.h"

Core *initCore(Instruction_Memory *i_mem)
{
	int i;

    Core *core = (Core *)malloc(sizeof(Core));
    core->clk = 0;
    core->PC = 0;
    core->instr_mem = i_mem;
    core->tick = tickFunc;

    // initialize register file here.
    // core->data_mem[0] = ...
	for (i=0; i<1024; i++) {
		core->data_mem[i] = 0;
	}

    // initialize data memory here.
    // core->reg_file[0] = ...
	for (i=0; i<32; i++) {
		core->reg_file[i] = 0;
	}

	core->data_mem[0] = 16;
	core->data_mem[1] = 128;
	core->data_mem[2] = 8;
	core->data_mem[3] = 4;

	core->reg_file[8] = 16;
	core->reg_file[10] = 4;
	core->reg_file[11] = 0;
	core->reg_file[22] = 1;
	core->reg_file[24] = 0;
	core->reg_file[25] = 4;

    return core;
}

// implement this function
bool tickFunc(Core *core)
{
    // Steps may include
    // (Step 1) Reading instruction from instruction memory
    Signal instruction = core->instr_mem->instructions[core->PC / 4].instruction;
    
    // (Step 2) Decode instruction
	Signal opcode = instruction & 0x7f;
	Signal rd = (instruction >> 7) & 0x1f;
	Signal funct3 = (instruction >> 12) & 0x7;
	Signal rs1 = (instruction >> 15) & 0x1f;
	Signal rs2 = (instruction >> 20) & 0x1f;
	Signal funct7 = (instruction >> 25) & 0x7f;
    
	// (Step 3) Generate control signals
	ControlSignals signals;
	ControlUnit(opcode, &signals);
	
	// (Step 4) ALU control unit
	Signal ALU_ctrl_signal = ALUControlUnit(signals.ALUOp, funct7, funct3);
	
	// (Step 5) Read values from register file
	Signal reg1_value = core->reg_file[rs1];
	Signal reg2_value = core->reg_file[rs2];
	
	// (Step 6) Immediate generator
	Signal immediate = ImmeGen(instruction);
	
	// (Step 7) ALU operation
	Signal ALU_result;
	Signal zero;
	Signal neg;

	Signal ALU_value2 = MUX(signals.ALUSrc, reg2_value, immediate);
	ALU(reg1_value, ALU_value2, ALU_ctrl_signal, &ALU_result, &zero, &neg);

	// (Step 8) Mux
	Signal mem_result = MUX(signals.MemtoReg,ALU_result, core->data_mem[ALU_result/4]);

	// (Step 9) Register file update
	if (signals.RegWrite) {
		core->reg_file[rd] = mem_result;
	}
	
	// (Step 10) Memory access
	if (signals.MemWrite) {
		core->data_mem[reg2_value / 4] = mem_result;
	}
	
    // (Step 11) Set PC 
	Signal branch_shift = ShiftLeft1(immediate);
   	Signal branch_sel=0;
	if (opcode == 99) {
		if (funct3 == 0) { // beq
			branch_sel = zero & signals.Branch;
		} else if (funct3 == 1) { // bne
			branch_sel = !zero & signals.Branch;
		} else if (funct3 == 4 || funct3 == 6) { // blt or bltu
			branch_sel = neg & signals.Branch;
		} else if (funct3 == 5 || funct3 == 7) { // bge or bgeu
			branch_sel = !neg & signals.Branch;
		}
	}
	Signal other_PC = core->PC + 4;
	Signal branch_PC = core->PC + branch_shift;
	core->PC = MUX(branch_sel, other_PC, branch_PC);

    ++core->clk;
    // Are we reaching the final instruction?
    if (core->PC > core->instr_mem->last->addr)
    {
        return false;
    }
    return true;
}

// (1). Control Unit. Refer to Figure 4.18.
void ControlUnit(Signal input,
                 ControlSignals *signals)
{
    if (input == 51) { // R-Type
        signals->ALUSrc = 0;
        signals->MemtoReg = 0;
        signals->RegWrite = 1;
        signals->MemRead = 0;
        signals->MemWrite = 0;
        signals->Branch = 0;
        signals->ALUOp = 2;
    } else if (input == 3) { // Load 
        signals->ALUSrc = 1;
        signals->MemtoReg = 1;
        signals->RegWrite = 1;
        signals->MemRead = 1;
        signals->MemWrite = 0;
        signals->Branch = 0;
        signals->ALUOp = 0;
    } else if (input == 19) { // I-Type 
        signals->ALUSrc = 1;
        signals->MemtoReg = 0;
        signals->RegWrite = 1;
        signals->MemRead = 0;
        signals->MemWrite = 0;
        signals->Branch = 0;
        signals->ALUOp = 0;
    } else if (input == 35) { // Store 
        signals->ALUSrc = 1;
        signals->MemtoReg = 0;
        signals->RegWrite = 0;
        signals->MemRead = 0;
        signals->MemWrite = 1;
        signals->Branch = 0;
        signals->ALUOp = 0;
    } else if (input == 99) { // Branch 
        signals->ALUSrc = 0;
        signals->MemtoReg = 0;
        signals->RegWrite = 0;
        signals->MemRead = 0;
        signals->MemWrite = 0;
        signals->Branch = 1;
        signals->ALUOp = 1;
    } else { // Default case
        signals->ALUSrc = 0;
        signals->MemtoReg = 0;
        signals->RegWrite = 0;
        signals->MemRead = 0;
        signals->MemWrite = 0;
        signals->Branch = 0;
        signals->ALUOp = 0;
	}
}

// (2). ALU Control Unit. Refer to Figure 4.12.
Signal ALUControlUnit(Signal ALUOp,
                      Signal Funct7,
                      Signal Funct3) 
{
	if (ALUOp == 0) {
		if (Funct7 == 0) {
			if (Funct3 == 1) { // shift left
				return 4;
			} else if (Funct3 == 5) { // shift right
				return 5;
			} else if (Funct3 == 0) { // add 
				return 2; // add
			} else if (Funct3 == 7) {
				return 0; // AND 
			} else if (Funct3 == 6) {
				return 1; // OR
			} else {
				return 2;
			}
		} else if (Funct7 == 32) { // subtract
			return 6; // subtract
		} else {
				printf("here");
			return 2;
		}
	} else if (ALUOp == 1) {
		return 6; // subtract
	} else if (ALUOp == 2) {
		if (Funct7 == 0) {
			if (Funct3 == 0) {
				return 2; // add 
			} else if (Funct3 == 7) {
				return 0; // AND 
			} else if (Funct3 == 6) {
				return 1; // OR
			} else if (Funct3 == 1) { // shift left
				return 4;
			} else if (Funct3 == 5) { // shift right
				return 5;
			}
		} else if (Funct7 == 32) {
			if (Funct3 == 0) { 
				return 6; // subtract
			}
		}
	} 
}

// (3). Imme. Generator
Signal ImmeGen(Signal input)
{
	Signal imm_12_0;
	unsigned opcode = input & 0x7f;

	// R-type 
	if (opcode == 51) {
		return 0;
	}

	// I-type and Load type
	if (opcode == 3 || opcode == 19) {
		// Shift input 20 bits to the right to get the 12 immediate bits
		imm_12_0 = (input >> 20) & 0xfff;
	} else if (opcode == 35) { // Store type
		Signal imm_4_0 = (input >> 7) & 0x1f;
		Signal imm_11_5 = (input >> 25) & 0x7f;
		imm_12_0 = (imm_11_5 << 5) | imm_4_0;
	} else if (opcode == 99) { // Branch type
		Signal imm_12 = (input >> 31) & 0x1;
		Signal imm_10_5 = (input >> 25) & 0x3f;
		Signal imm_4_1 = (input >> 8) & 0xf;
		Signal imm_11 = (input >> 7) & 0x1;

		imm_12_0 = (imm_12 << 11) | (imm_11 << 10) | (imm_10_5 << 4) | (imm_4_1);
	}

	// If the 11th bit is 1 then add 20 1s to the right, else let it be
	if (imm_12_0 & (1 << 11)) {
		imm_12_0 = imm_12_0 | 0xfffffffffffff000;
	} 
	return imm_12_0;
}

// (4). ALU
void ALU(Signal input_0,
         Signal input_1,
         Signal ALU_ctrl_signal,
         Signal *ALU_result,
         Signal *zero,
		 Signal *neg)
{
    if (ALU_ctrl_signal == 2) { // add
        *ALU_result = (input_0 + input_1);
    } else if (ALU_ctrl_signal == 0) { // AND
		*ALU_result = (input_0 & input_1);
	} else if (ALU_ctrl_signal == 1) { // OR
		*ALU_result = input_0 | input_1;
	} else if (ALU_ctrl_signal == 6) { // subtract
		*ALU_result = input_0 - input_1;
	} else if (ALU_ctrl_signal == 4) { // shift left
		*ALU_result = input_0 << input_1;
	} else if (ALU_ctrl_signal == 5) { // shift right
		*ALU_result = input_0 >> input_1;
	}	
	
	if (*ALU_result == 0) { *zero = 1; } else { *zero = 0; }
	if (*ALU_result < 0) { *neg = 1; } else { *neg = 0; }
}

// (4). MUX
Signal MUX(Signal sel,
           Signal input_0,
           Signal input_1)
{
    if (sel == 0) { return input_0; } else { return input_1; }
}

// (5). Add
Signal Add(Signal input_0,
           Signal input_1)
{
    return (input_0 + input_1);
}

// (6). ShiftLeft1
Signal ShiftLeft1(Signal input)
{
    return input << 1;
}
